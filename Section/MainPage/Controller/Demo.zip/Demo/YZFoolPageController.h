//
//  YZFoolPageController.h
//  Section
//
//  Created by QZL on 2017/7/6.
//  Copyright © 2017年 WTF. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface YZFoolPageController : UIViewController

@end
